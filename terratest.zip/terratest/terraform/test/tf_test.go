package test

import (
    "fmt"
	"testing"

    "github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/aws"
	"github.com/gruntwork-io/terratest/modules/terraform"

	awsSDK "github.com/aws/aws-sdk-go/aws"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestTerraformECSandVPC(t *testing.T) {
	t.Parallel()

    awsRegion := aws.GetRandomStableRegion(t, []string{"us-east-2", "us-west-1"}, nil)

	vpc_cidr_block := "1.0.0.0/16"
	public_subnet_A := "1.0.1.0/24"
	public_subnet_C := "1.0.2.0/24"
	nat_subnet_A := "1.0.3.0/24"
	nat_subnet_C := "1.0.4.0/24"

	expectedClusterName := fmt.Sprintf("terratest-ecs-cluster-%s", random.UniqueId())
	expectedServiceName := fmt.Sprintf("terratest-ecs-service-%s", random.UniqueId())

	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../infra/",

		Vars: map[string]interface{}{
			"cluster_name": expectedClusterName,
			"service_name": expectedServiceName,
			"vpc_cidr_block": vpc_cidr_block,
			"public_subnet_A": public_subnet_A,
			"public_subnet_C": public_subnet_C,
			"nat_subnet_A": nat_subnet_A,
			"nat_subnet_C": nat_subnet_C,
			"region": awsRegion,
		},
	})

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

// testing fargate services
	taskDefinition := terraform.Output(t, terraformOptions, "task_definition")
	cluster := aws.GetEcsCluster(t, awsRegion, expectedClusterName)
	assert.Equal(t, int64(1), awsSDK.Int64Value(cluster.ActiveServicesCount))
	service := aws.GetEcsService(t, awsRegion, expectedClusterName, expectedServiceName)
	assert.Equal(t, int64(1), awsSDK.Int64Value(service.DesiredCount))
	assert.Equal(t, "FARGATE", awsSDK.StringValue(service.LaunchType))
	task := aws.GetEcsTaskDefinition(t, awsRegion, taskDefinition)
	assert.Equal(t, "256", awsSDK.StringValue(task.Cpu))
	assert.Equal(t, "512", awsSDK.StringValue(task.Memory))
	assert.Equal(t, "awsvpc", awsSDK.StringValue(task.NetworkMode))

// 	testing vpc
	public_subnet_A_ID := terraform.Output(t, terraformOptions, "public_subnet_A_ID")
	public_subnet_C_ID := terraform.Output(t, terraformOptions, "public_subnet_C_ID")
	nat_subnet_A_ID := terraform.Output(t, terraformOptions, "nat_subnet_A_ID")
	nat_subnet_C_ID := terraform.Output(t, terraformOptions, "nat_subnet_C_ID")
	vpcId := terraform.Output(t, terraformOptions, "vpcId")
	subnets := aws.GetSubnetsForVpc(t, vpcId, awsRegion)

	require.Equal(t, 4, len(subnets))
	assert.True(t, aws.IsPublicSubnet(t, public_subnet_A_ID, awsRegion))
	assert.True(t, aws.IsPublicSubnet(t, public_subnet_C_ID, awsRegion))
	assert.False(t, aws.IsPublicSubnet(t, nat_subnet_A_ID, awsRegion))
	assert.False(t, aws.IsPublicSubnet(t, nat_subnet_C_ID, awsRegion))
}
